from code_runner_files.AbstractCodeRunner import AbstractCodeRunner
import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns

class MyCode(AbstractCodeRunner):
    def run_code(self):

        #Read data 
        #Please, do not edit this line of code.
        data = self.dataset.__getdata__()

        #Code to run
        #Add here the code to run. You can create different functions and the results should be clear stated.
        label = "contraceptive_method_used"
        y = data[label].astype('category')
        class_names = y.cat.categories.tolist()
        x = data.drop(label, axis=1, inplace=False)
        classification_metrics, y_test, y_pred = classification(X=x, y=y)
        confussion_matrix = plot_confussion_matrix(y_test=y_test, y_pred=y_pred, class_names=class_names)

        #Gather results
        #The results variable should be a list of dicts. Each dict element must have the following elements:
        # "data": the results, "name": name of the results (will be used a the filename in which this resuls will be stored),
        # and "format": the format in which you want to store the results (fig, csv, txt for the moment)
        results = [
            {
                "data": classification_metrics,
                "name": "classification_report",
                "format": "txt"
            }, {
                "data": confussion_matrix,
                "name": "confussion_matrix",
                "format": "fig"
            }
        ]
        return results


def preprocess_data(data):
    # get categorical attributes
    categorical_vars = data.select_dtypes(include=["object","category"])

    # label encoder each categorical attribute
    for c in categorical_vars.columns.tolist():
        categorical_vars[c] = LabelEncoder().fit_transform(categorical_vars[c])

    # one-hot encode categorical variables
    onehot_encoder_x = OneHotEncoder()
    x_cat = onehot_encoder_x.fit_transform(categorical_vars).toarray()

    # standardize numerical variables
    numerical_vars = data.select_dtypes(include=["int64", "float64"])
    x_num = StandardScaler().fit_transform(numerical_vars)

    # return the standardized numerical attributes stacked with the one-hot encoded categorical attributes
    return np.column_stack((x_num, x_cat))    


def classification(X, y):

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    X_train_scaled = preprocess_data(data=X_train)
    classifier = RandomForestClassifier().fit(X_train_scaled, y_train)

    X_test_scaled = preprocess_data(data=X_test)
    y_pred = classifier.predict(X_test_scaled)

    return classification_report(y_test, y_pred), y_test, y_pred


def plot_confussion_matrix(y_test, y_pred, class_names):
    cm = confusion_matrix(y_test, y_pred)
    fig = plt.figure(figsize=(8,6))
    sns.heatmap(cm, annot=True, fmt='g', cmap='Blues', cbar=False, xticklabels=class_names, yticklabels=class_names)
    plt.title('Confusion Matrix')
    plt.xlabel('Predicted values')
    plt.ylabel('Real values')
    plt.show()
    return fig





