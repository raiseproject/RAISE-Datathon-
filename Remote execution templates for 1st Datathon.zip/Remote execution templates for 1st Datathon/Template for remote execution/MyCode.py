#Needed import. Please, do not edit the following import
from code_runner_files.AbstractCodeRunner import AbstractCodeRunner

#Import here any additional packages you used
#import numpy as np
#import pandas as pd

class MyCode(AbstractCodeRunner):
    def run_code(self):

        #Read data 
        #Please, do not edit this line of code.
        data = self.dataset.__getdata__()

        #Code to run
        #Add here the code to run. You can create different functions and the results should be clear stated.

        #Gather results
        #The results variable should be a list of dicts. Each dict element must have the following elements:
        # "data": the results,
        # "name": name of the results (will be used a the filename in which this resuls will be stored),
        # "format": the format in which you want to store the results (fig, csv, txt for the moment)
        results = [
            {
                "data": None, #Add your results data here (figure, dataframe, list, value...)
                "name": "resul_name", #Add the name or tag of your results (this will be used for titled the created document with the results
                "format": "txt" #Choose the format of your results (fig for figure, txt for list of values or unique values, or csv for dataframe)
            }
        ]
        return results



