from code_runner_files.AbstractCodeRunner import AbstractCodeRunner
import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.decomposition import PCA
import pandas as pd

class MyCode(AbstractCodeRunner):
    def run_code(self):

        #Read data 
        #Please, do not edit this line of code.
        data = self.dataset.__getdata__()

        #Code to run
        #Add here the code to run. You can create different functions and the results should be clear stated.
        preprocessed_data = preprocess_data(data=data)
        pca_matrix = compute_principal_components(data=preprocessed_data)
        pca_figure = plot_pca_figure(data=preprocessed_data)

        #Gather results
        #The results variable should be a list of dicts. Each dict element must have the following elements:
        # "data": the results, "name": name of the results (will be used a the filename in which this resuls will be stored),
        # and "format": the format in which you want to store the results (fig, csv, txt for the moment)
        results = [
            {
                "data": pca_matrix,
                "name": "principal_component_analysis_matrix",
                "format": "csv"
            }, {
                "data": pca_figure,
                "name": "principal_component_analysis_figure",
                "format": "fig"
            }
        ]
        return results
    

def preprocess_data(data):
    # get categorical attributes
    categorical_vars = data.select_dtypes(include=["object","category"])

    # label encoder each categorical attribute
    for c in categorical_vars.columns.tolist():
        categorical_vars[c] = LabelEncoder().fit_transform(categorical_vars[c])

    # one-hot encode categorical variables
    onehot_encoder_x = OneHotEncoder()
    x_cat = onehot_encoder_x.fit_transform(categorical_vars).toarray()

    # standardize numerical variables
    numerical_vars = data.select_dtypes(include=["int64", "float64"])
    x_num = StandardScaler().fit_transform(numerical_vars)

    # return the standardized numerical attributes stacked with the one-hot encoded categorical attributes
    return np.column_stack((x_num, x_cat))    


def compute_principal_components(data):
    pca_transformer = PCA(n_components=0.95, random_state=64)
    pca_values = pca_transformer.fit_transform(data)
    colnames = []
    for i in range(0,pca_values.shape[1]):
        colnames.append(f"PC{i}")
    pca_df = pd.DataFrame(data=pca_values, index=list(range(0,pca_values.shape[0])), columns=colnames)
    return pca_df


def plot_pca_figure(data):
    fig = plt.figure()
    pca_values = PCA(n_components=2).fit_transform(data)
    pca_df = pd.DataFrame(data=pca_values, columns=["PC1", "PC2"])
    plt.scatter(pca_df["PC1"], pca_df["PC2"], s=20, alpha=0.5)
    plt.title('Principal Component Analysis (PCA)')
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    return fig





