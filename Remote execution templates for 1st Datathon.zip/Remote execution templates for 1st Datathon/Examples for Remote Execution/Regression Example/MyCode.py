from code_runner_files.AbstractCodeRunner import AbstractCodeRunner
import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

import pandas as pd

class MyCode(AbstractCodeRunner):
    def run_code(self):

        #Read data 
        #Please, do not edit this line of code.
        data = self.dataset.__getdata__()

        #Code to run
        #Add here the code to run. You can create different functions and the results should be clear stated.
        label = "label_col_name"
        y = data[label]
        x = data.drop(label, axis=1, inplace=False)
        regression_metrics, y_test, y_pred = regression(X=x, y=y)
        regression_plot = plot_predictions(y_test=y_test, y_pred=y_pred)

        #Gather results
        #The results variable should be a list of dicts. Each dict element must have the following elements:
        # "data": the results, "name": name of the results (will be used a the filename in which this resuls will be stored),
        # and "format": the format in which you want to store the results (fig, csv, txt for the moment)
        results = [
            {
                "data": regression_metrics,
                "name": "regression_metrics",
                "format": "txt"
            }, {
                "data": regression_plot,
                "name": "regression_plot",
                "format": "fig"
            }
        ]
        return results


def preprocess_data(data):
    # get categorical attributes
    categorical_vars = data.select_dtypes(include=["object","category"])

    # label encoder each categorical attribute
    for c in categorical_vars.columns.tolist():
        categorical_vars[c] = LabelEncoder().fit_transform(categorical_vars[c])

    # one-hot encode categorical variables
    onehot_encoder_x = OneHotEncoder()
    x_cat = onehot_encoder_x.fit_transform(categorical_vars).toarray()

    # standardize numerical variables
    numerical_vars = data.select_dtypes(include=["int64", "float64"])
    x_num = StandardScaler().fit_transform(numerical_vars)

    # return the standardized numerical attributes stacked with the one-hot encoded categorical attributes
    return np.column_stack((x_num, x_cat))    


def regression(X, y):

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    X_train_scaled = preprocess_data(data=X_train)
    regressor = RandomForestRegressor().fit(X_train_scaled, y_train)

    X_test_scaled = preprocess_data(data=X_test)
    y_pred = regressor.predict(X_test_scaled)

    regression_metrics = {
        "Mean Squared Error (MSE)" : mean_squared_error(y_test, y_pred),
        "Mean Absolute Error (MAE)" : mean_absolute_error(y_test, y_pred),
        "R2 Score": r2_score(y_test, y_pred)
    }

    return str(regression_metrics), y_test, y_pred


def plot_predictions(y_test, y_pred):
    fig = plt.figure(figsize=(8,6))
    plt.scatter(y_test, y_pred, s=20, alpha=0.5)
    plt.plot([min(y_test), max(y_test)], [min(y_test), max(y_test)], linestyle='--', color='red', linewidth=2)
    plt.title('Scatter plot (Real values vs. Predicted values)')
    plt.xlabel('Real values')
    plt.ylabel('Predicted values')
    plt.tight_layout()
    return fig




