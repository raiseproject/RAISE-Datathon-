from code_runner_files.AbstractCodeRunner import AbstractCodeRunner
import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import LabelEncoder
import seaborn as sns

class MyCode(AbstractCodeRunner):
    def run_code(self):

        #Read data 
        #Please, do not edit this line of code.
        data = self.dataset.__getdata__()

        #Code to run
        #Add here the code to run. You can create different functions and the results should be clear stated.
        pearson_correlation_matrix = compute_pearson_correlation_matrix(data=data)
        pearson_correlation_matrix_figure = plot_pearson_correlation_matrix(correlations=pearson_correlation_matrix)

        #Gather results
        #The results variable should be a list of dicts. Each dict element must have the following elements:
        # "data": the results, "name": name of the results (will be used a the filename in which this resuls will be stored),
        # and "format": the format in which you want to store the results (fig, csv, txt for the moment)
        results = [
            {
                "data": pearson_correlation_matrix,
                "name": "pearson_correlation_matrix",
                "format": "csv"
            }, {
                "data": pearson_correlation_matrix_figure,
                "name": "pearson_correlation_matrix",
                "format": "fig"
            }
        ]
        return results
    

def compute_pearson_correlation_matrix(data):
    categorical_cols = data.select_dtypes(include=["object", "category"]).columns
    for col in categorical_cols:
        data[col] = LabelEncoder().fit_transform(data[col])
    return data.corr(method="pearson")


def plot_pearson_correlation_matrix(correlations):
    fig, ax = plt.subplots(nrows=1, ncols=1)
    correlations = correlations.iloc[1:, 0:-1]
    cors_mask = np.triu(np.ones_like(correlations, dtype=bool)) - np.identity(len(correlations))
    sns.heatmap(correlations, linewidths=0.3, ax=ax, mask=cors_mask, cbar=True, vmin=0, vmax=1, cmap="Blues", annot=False)
    plt.title('Pearson Correlation Matrix of dataset')
    return fig




